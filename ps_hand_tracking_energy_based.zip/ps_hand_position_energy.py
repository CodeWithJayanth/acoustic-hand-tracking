"""
Hand Tracking using Mic Energy (No ML)

This script:
- Reads mic0–mic15 from AXI-Lite registers
- Classifies hand as "Left", "Center", or "Right" based on energy grouping
"""

import os, mmap, struct, time

# AXI Settings
AXI_BASE_ADDR = 0x43C00000
AXI_SIZE = 0x1000
NUM_MICS = 16
MIC_REG_OFFSET = 0x00
TIMESTAMP_REG_OFFSET = 0x40

def read_reg(mem, offset):
    mem.seek(offset)
    return struct.unpack("<I", mem.read(4))[0]

def classify_hand_position(mic_values):
    # Group energy by region
    left_energy = sum(mic_values[0:5])
    center_energy = sum(mic_values[5:11])
    right_energy = sum(mic_values[11:16])

    max_energy = max(left_energy, center_energy, right_energy)

    if max_energy == left_energy:
        return "Left"
    elif max_energy == center_energy:
        return "Center"
    else:
        return "Right"

def main():
    # Map AXI memory
    fd = os.open("/dev/mem", os.O_RDWR | os.O_SYNC)
    mem = mmap.mmap(fd, AXI_SIZE, mmap.MAP_SHARED,
                    mmap.PROT_READ | mmap.PROT_WRITE, offset=AXI_BASE_ADDR)

    try:
        print("Hand tracking via mic energy... (Press Ctrl+C to exit)")
        while True:
            mic_data = [read_reg(mem, MIC_REG_OFFSET + i*4) for i in range(NUM_MICS)]
            timestamp = read_reg(mem, TIMESTAMP_REG_OFFSET)
            position = classify_hand_position(mic_data)

            # Show hand estimate + sample mic values
            print(f"Time: {timestamp} | Hand: {position} | Mic0: {mic_data[0]} | Mic7: {mic_data[7]} | Mic15: {mic_data[15]}")
            time.sleep(0.01)

    except KeyboardInterrupt:
        print("Exiting.")
    finally:
        mem.close()
        os.close(fd)

if __name__ == "__main__":
    main()
