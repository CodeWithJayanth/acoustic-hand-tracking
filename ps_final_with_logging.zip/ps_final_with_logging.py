"""
Final demo script with:
- GPIO sync pulse wait
- AXI-Lite mic0–mic15 + timestamp read
- Sampling rate tracking
- CSV logging to mic_data_log.csv
"""

import os, mmap, struct, time, csv

# GPIO Setup
GPIO_PIN = 68
GPIO_PATH = f"/sys/class/gpio/gpio{GPIO_PIN}/value"

# AXI Settings
AXI_BASE_ADDR = 0x43C00000
AXI_SIZE = 0x1000
NUM_MICS = 16
MIC_REG_OFFSET = 0x00
TIMESTAMP_REG_OFFSET = 0x40

# Wait for GPIO sync
def wait_for_sync_gpio():
    print(f"Waiting for sync pulse on GPIO{GPIO_PIN}...")
    while True:
        with open(GPIO_PATH, 'r') as f:
            val = f.read().strip()
        if val == "1":
            print("Sync pulse received!")
            break
        time.sleep(0.001)

# Read a 32-bit AXI register
def read_reg(mem, offset):
    mem.seek(offset)
    return struct.unpack("<I", mem.read(4))[0]

# Main logic
def main():
    # Map AXI
    fd = os.open("/dev/mem", os.O_RDWR | os.O_SYNC)
    mem = mmap.mmap(fd, AXI_SIZE, mmap.MAP_SHARED, mmap.PROT_READ | mmap.PROT_WRITE, offset=AXI_BASE_ADDR)

    try:
        wait_for_sync_gpio()
        print("Starting mic read loop...")

        count = 0
        t_start = time.time()

        # Setup CSV logging
        with open("mic_data_log.csv", "w", newline="") as logfile:
            writer = csv.writer(logfile)
            writer.writerow(["timestamp"] + [f"mic{i}" for i in range(NUM_MICS)])

            while True:
                mic_data = [read_reg(mem, MIC_REG_OFFSET + i*4) for i in range(NUM_MICS)]
                timestamp = read_reg(mem, TIMESTAMP_REG_OFFSET)

                # Print all mics
                mic_str = " | ".join([f"Mic{i}: {mic_data[i]}" for i in range(NUM_MICS)])
                print(f"Timestamp: {timestamp} | {mic_str}")

                # Log to CSV
                writer.writerow([timestamp] + mic_data)

                count += 1
                if count % 96 == 0:
                    elapsed = time.time() - t_start
                    if elapsed > 0:
                        rate = int(count / elapsed)
                        print(f"Sampling Rate: {rate} samples/sec (expected ~96000)")
                        count = 0
                        t_start = time.time()

                time.sleep(0.0005)

    except KeyboardInterrupt:
        print("Exiting.")
    finally:
        mem.close()
        os.close(fd)

if __name__ == "__main__":
    main()
